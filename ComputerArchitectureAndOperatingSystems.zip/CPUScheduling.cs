﻿using classobj;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPUConsole
{
    class CPUScheduling
    {
        public List<Scheduled_Process> First_Come_First_Serve(List<Process> processes)
        {
            //Arrange by arrival time
            processes = rearrange_processes_byArrivalTime(processes);

            //Schedule Processes
            List<Scheduled_Process> scheduled_processes = new List<Scheduled_Process>();
            int end_timestamp = 0;
            int start_timestamp;
            foreach (Process p in processes)
            {
                start_timestamp = end_timestamp;

                //When process arrives after idle
                if (p.arrival_time > start_timestamp)
                {
                    scheduled_processes.Add(new Scheduled_Process(start_timestamp, p.arrival_time));
                    end_timestamp = p.burst_time + p.arrival_time;
                    scheduled_processes.Add(new Scheduled_Process(p, p.arrival_time, end_timestamp));
                }
                else
                {
                    end_timestamp += p.burst_time;
                    scheduled_processes.Add(new Scheduled_Process(p, start_timestamp, end_timestamp));
                }
            }

            //Calculate turn around time
            foreach(Scheduled_Process scheduled_process in scheduled_processes)
            {
                //turnaround time = time stamp where process finished - process arrival time
                Console.WriteLine(scheduled_process.end_timestamp + " " + scheduled_process.process.arrival_time );
                scheduled_process.process.turnaround_time = scheduled_process.end_timestamp - scheduled_process.process.arrival_time;
            }

            //Calculate waiting time
            foreach (Scheduled_Process scheduled_process in scheduled_processes)
            {
                //waiting time = turnaround time - burst time
                scheduled_process.process.waiting_time = scheduled_process.process.turnaround_time - scheduled_process.process.burst_time;
            }

            return scheduled_processes;
        }

        public List<Scheduled_Process> Nonpremptive_Priority(List<Process> processes)
        {
            //Arrange by arrival time
            processes = rearrange_processes_byArrivalTime(processes);
            //Arrange by priority
            processes = rearrange_processes_byPriority(processes);

            //Schedule Processes
            List<Scheduled_Process> scheduled_processes = new List<Scheduled_Process>();
            int end_timestamp = 0;
            int start_timestamp;
            foreach (Process p in processes)
            {
                start_timestamp = end_timestamp;

                //When process arrives after idle
                if (p.arrival_time > start_timestamp)
                {
                    scheduled_processes.Add(new Scheduled_Process(start_timestamp, p.arrival_time));
                    end_timestamp = p.burst_time + p.arrival_time;
                    scheduled_processes.Add(new Scheduled_Process(p, p.arrival_time, end_timestamp));
                }
                else
                {
                    end_timestamp += p.burst_time;
                    scheduled_processes.Add(new Scheduled_Process(p, start_timestamp, end_timestamp));
                }
            }

            //Calculate turn around time
            foreach (Scheduled_Process scheduled_process in scheduled_processes)
            {
                //turnaround time = time stamp where process finished - process arrival time
                Console.WriteLine(scheduled_process.end_timestamp + " " + scheduled_process.process.arrival_time);
                scheduled_process.process.turnaround_time = scheduled_process.end_timestamp - scheduled_process.process.arrival_time;
            }

            //Calculate waiting time
            foreach (Scheduled_Process scheduled_process in scheduled_processes)
            {
                //waiting time = turnaround time - burst time
                scheduled_process.process.waiting_time = scheduled_process.process.turnaround_time - scheduled_process.process.burst_time;
            }

            return scheduled_processes;
        }

        /// <summary>
        /// Rearrange processes by arrival time in ascending order
        /// </summary>
        /// <param name="processes"></param>
        /// <returns></returns>
        private List<Process> rearrange_processes_byArrivalTime(List<Process> processes)
        {
            return processes.OrderBy(o => o.arrival_time).ToList();
        }

        /// <summary>
        /// Rearrange processes by priority
        /// </summary>
        /// <param name="processes"></param>
        /// <returns></returns>
        private List<Process> rearrange_processes_byPriority(List<Process> processes)
        {
            return processes.OrderByDescending(o => o.priority).ToList();
        }
    }

}
